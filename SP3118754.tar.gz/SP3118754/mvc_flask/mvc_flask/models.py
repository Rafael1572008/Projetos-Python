class Tarefa:
    def __init__(self, id, descricao, concluido = False):
        self.id = id
        self.descricao = descricao
        self.concluido = concluido

tarefas = []

t = Tarefa(1, "dormi", "comer")
tarefas.append(t)
t2 = Tarefa(2, "comer", True)
tarefas.append(t2)