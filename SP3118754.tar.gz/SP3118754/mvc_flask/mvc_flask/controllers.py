from flask import Blueprint, render_template
from .models import tarefas

tarefa_controllers = Blueprint('tarefa', __name__)

@tarefa_controllers.route('/')
def index():
    return render_template('index.html', tarefas = tarefas)