class Tarefa:
    def __init__(self, id, descricao, completo=False):
        self.id = id
        self.des = descricao
        self.completado = completo

tarefas = []

def add_tarefas(descricao):
    id = len(tarefas) + 1
    nova_tarefa = tarefas(id, descricao)
    Tarefa.append(nova_tarefa)
