from flask import Blueprint, render_template, request, redirect, url_for
from .model import tarefa, add_tarefa

tarefa_controller = Blueprint('tarefas', __name__)

@tarefa_controller.route('/')
def index():
    return render_template('index.html', tarefa=tarefa)

@tarefa_controller.route('/add', methods=['POST'])
def add():
    descricao = request.form['descricao']
    add_tarefa(descricao)
    return redirect(url_for('tarefa.index'))
